import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const FavoriteMoviesPage = () => {
  const [favoriteMovies, setFavoriteMovies] = useState([
    { id: 1, title: 'Barbie', favorite: false },
    { id: 2, title: 'Tropa de Elite', favorite: false },
    { id: 3, title: 'Frozen', favorite: false },
    { id: 1, title: 'Toy Story', favorite: false },
    { id: 2, title: 'Turma da Mônica', favorite: false },
    { id: 3, title: 'Chucky', favorite: false },
    // Adicione mais filmes favoritos aqui
  ]);

  const toggleFavorite = (movieId) => {
    setFavoriteMovies(prevMovies =>
      prevMovies.map(movie =>
        movie.id === movieId ? { ...movie, favorite: !movie.favorite } : movie
      )
    );
  };

  const renderMovieItem = ({ item }) => (
    <TouchableOpacity style={styles.movieItem} onPress={() => toggleFavorite(item.id)}>
      <Text style={styles.movieTitle}>{item.title}</Text>
      <Ionicons
        name={item.favorite ? 'heart' : 'heart-outline'}
        size={24}
        color={item.favorite ? 'red' : 'black'}
      />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Meus Filmes Favoritos</Text>
      <FlatList
        data={favoriteMovies}
        renderItem={renderMovieItem}
        keyExtractor={item => item.id.toString()}
      />
    </View>
  );
};

const styles = {
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  movieItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    padding: 12,
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
  },
  movieTitle: {
    flex: 1,
    fontSize: 16,
  },
};

export default FavoriteMoviesPage;
