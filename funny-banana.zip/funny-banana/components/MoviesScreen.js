import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, ScrollView, StyleSheet, Image } from 'react-native';

const MoviesScreen = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [movies, setMovies] = useState([]);
  const [showMovies, setShowMovies] = useState(false);

  const handleSearchMovies = () => {
    const moviesData = [
      { id: 1, title: 'Barbie', description: 'No mundo mágico das Barbies, “Barbieland”, uma das bonecas começa a perceber que não se encaixa como as outras. Depois de ser expulsa, ela parte para uma aventura no “mundo real”, onde descobre que a beleza está no interior de cada um.', cover: require('../assets/barbie.png') },
      { id: 2, title: 'O Hobbit', description: 'Como a maioria dos hobbits, Bilbo Bolseiro leva uma vida tranquila até o dia em que recebe uma missão do mago Gandalf. Acompanhado por um grupo de anões, ele parte numa jornada até a Montanha Solitária para libertar o Reino de Erebor do dragão Smaug.', cover: require('../assets/ohobbit.png') },
      { id: 3, title: 'Tatuagem', description: 'Clécio Wanderley é o líder da trupe teatral Chão de Estrelas. Paulete é a principal estrela da equipe. Um dia, Paulette recebe a visita de seu cunhado, o jovem Fininha, que é militar. Encantado com o universo criado pela companhia, ele logo é seduzido por Clécio. Os dois engatam um tórrido relacionamento, que coloca Fininha em situação complicada: ele precisa lidar com a repressão existente no meio militar em plena ditadura.', cover: require('../assets/tatuagem.png') },
    ];

    setMovies(moviesData);
    setShowMovies(true);
  };

  const handleGoBack = () => {
    setShowMovies(false);
  };

  const handleMoviePress = (movie) => {
    setSelectedMovie(movie);
    setModalVisible(true);
  };

  const handleCloseModal = () => {
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Catálogo de Filmes</Text>
      {!showMovies ? (
        <TouchableOpacity onPress={handleSearchMovies} style={styles.searchButton}>
          <Text style={styles.searchButtonText}>Pesquisar Filmes</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={handleGoBack} style={styles.backButton}>
          <Text style={styles.backButtonText}>Voltar</Text>
        </TouchableOpacity>
      )}
      {showMovies && (
        <ScrollView contentContainerStyle={styles.moviesContainer}>
          {movies.map((movie) => (
            <TouchableOpacity key={movie.id} onPress={() => handleMoviePress(movie)} style={styles.movieItem}>
              <Image source={movie.cover} style={styles.movieCover} />
              <Text style={styles.movieTitle}>{movie.title}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
      <Modal visible={modalVisible} animationType="slide">
        <View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>{selectedMovie?.title}</Text>
          <Text style={styles.modalDescription}>{selectedMovie?.description}</Text>
          <TouchableOpacity onPress={handleCloseModal} style={styles.modalCloseButton}>
            <Text style={styles.modalCloseButtonText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  searchButton: {
    backgroundColor: '#007bff',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  searchButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  backButton: {
    backgroundColor: '#dc3545',
    paddingVertical: 10,
paddingHorizontal: 20,
borderRadius: 5,
},
backButtonText: {
color: '#fff',
fontSize: 16,
},
moviesContainer: {
marginTop: 20,
},
movieItem: {
backgroundColor: '#fff',
padding: 10,
marginBottom: 10,
borderRadius: 5,
flexDirection: 'row',
alignItems: 'center',
},
movieCover: {
width: 80,
height: 120,
marginRight: 10,
borderRadius: 5,
},
movieTitle: {
fontSize: 16,
},
modalContainer: {
flex: 1,
alignItems: 'center',
justifyContent: 'center',
backgroundColor: '#fff',
padding: 20,
},
modalTitle: {
fontSize: 24,
fontWeight: 'bold',
marginBottom: 10,
},
modalDescription: {
fontSize: 16,
marginBottom: 20,
},
modalCloseButton: {
backgroundColor: '#007bff',
paddingVertical: 10,
paddingHorizontal: 20,
borderRadius: 5,
},
modalCloseButtonText: {
color: '#fff',
fontSize: 16,
},
});

export default MoviesScreen;
